﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Collections.Generic;
using System.Linq;

public class Packet
{
    public string Symbol { get; set; }
    public string BuySellIndicator { get; set; }
    public int Quantity { get; set; }
    public int Price { get; set; }
    public int PacketSequence { get; set; }
}

class Program
{
    const int PacketSize = 17;

    static void Main()
    {
        var packets = new Dictionary<int, Packet>();

        Console.WriteLine("Connecting to server...");
        using (var client = new TcpClient("127.0.0.1", 3000))
        using (var stream = client.GetStream())
        {
            stream.Write(new byte[] { 1, 0 }, 0, 2);

            var buffer = new byte[PacketSize];
            int bytesRead;
            var leftover = new List<byte>();

            try
            {
                while ((bytesRead = stream.Read(buffer, 0, PacketSize)) > 0)
                {
                    var actual = buffer.Take(bytesRead).ToArray();
                    leftover.AddRange(actual);

                    while (leftover.Count >= PacketSize)
                    {
                        var packetBytes = leftover.Take(PacketSize).ToArray();
                        leftover = leftover.Skip(PacketSize).ToList();

                        var packet = ParsePacket(packetBytes);
                        packets[packet.PacketSequence] = packet;
                    }
                }
            }
            catch (IOException)
            {
                // Server closed connection
            }
        }

        var allSeq = packets.Keys.OrderBy(k => k).ToList();
        int maxSeq = allSeq.Max();
        var missing = Enumerable.Range(1, maxSeq).Except(allSeq).ToList();

        Console.WriteLine("Missing packets: " + string.Join(", ", missing));

        foreach (var seq in missing)
        {
            using (var retryClient = new TcpClient("127.0.0.1", 3000))
            using (var retryStream = retryClient.GetStream())
            {
                retryStream.Write(new byte[] { 2, (byte)seq }, 0, 2);

                var retryBuffer = new byte[PacketSize];
                int totalRead = 0;

                while (totalRead < PacketSize)
                {
                    int read = retryStream.Read(retryBuffer, totalRead, PacketSize - totalRead);
                    if (read == 0) break;
                    totalRead += read;
                }

                var packet = ParsePacket(retryBuffer);
                packets[packet.PacketSequence] = packet;
            }
        }

        var finalList = packets.OrderBy(p => p.Key).Select(p => p.Value).ToList();
        var json = JsonSerializer.Serialize(finalList, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText("output.json", json);

        Console.WriteLine("All packets saved to output.json");
    }

    static Packet ParsePacket(byte[] data)
    {
        return new Packet
        {
            Symbol = Encoding.ASCII.GetString(data[0..4]),
            BuySellIndicator = Encoding.ASCII.GetString(data[4..5]),
            Quantity = BitConverter.ToInt32(data[5..9].Reverse().ToArray(), 0),
            Price = BitConverter.ToInt32(data[9..13].Reverse().ToArray(), 0),
            PacketSequence = BitConverter.ToInt32(data[13..17].Reverse().ToArray(), 0)
        };
    }
}
